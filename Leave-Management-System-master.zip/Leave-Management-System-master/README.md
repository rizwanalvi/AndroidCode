# Leave-Management-System
Android application to enable employee to issue leave request and employer to grant/reject the request using cloud services
