package rapticon.tk.leavemanagement.model;


import java.io.Serializable;

public class BaseElement implements Serializable{
}
