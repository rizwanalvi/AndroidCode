package rapticon.tk.leavemanagement.exception;

import java.io.IOException;

public class NoInternetException extends IOException {

    public NoInternetException(String detailMessage) {
        super(detailMessage);
    }
}
